# SQL Database Relationship Analysis

The database contains the following tables:

1. `tSearchArea`
2. `sqlite_sequence` (internal SQLite table for autoincrement values)
3. `tDirectory`
4. `tFile`
5. `tTdmFileviewNames`
6. `tTdmFileview`
7. `tTdmRoot`
8. `tTdmRootIANames`
9. `tTdmRootIA`
10. `tTdmGroup`
11. `tTdmGroupIANames`
12. `tTdmGroupIA`
13. `tTdmChannel`
14. `tTdmChannelIANames`
15. `tTdmChannelIA`
16. `tMasterInformation`

```puml
@startuml
!define primary_key(x) <b>x</b>
!define foreign_key(x) <i>x</i>

entity tDirectory {
  primary_key(dirID)
  parentDirID
  rootDirID
  name
  fullpath
  createTime
  modifyTime
  included
  attributes
}

entity tFile {
  primary_key(fileID)
  foreign_key(dirID)
  name
  filesize
  createTime
  modifyTime
  attributes
}

entity tTdmFileview {
  primary_key(tdmfileviewID)
  foreign_key(fileID)
  iaID
  indexStatus
  errorLog
  modifyTimeAtIndexing
  indexingTime
  fileviewSize
}

entity tTdmRoot {
  primary_key(rootID)
  foreign_key(fileviewID)
  name
  description
  title
  author
  datetime
  registertxt1
  registertxt2
  registertxt3
}

entity tTdmRootIA {
  foreign_key(rootID)
  foreign_key(iaID)
  datatype
  val_str
  val_double
  val_int
  val_time
}

entity tTdmRootIANames {
  primary_key(iaID)
  name
  refCount
  datatype
}

entity tTdmGroup {
  primary_key(groupID)
  foreign_key(rootID)
  groupIndex
  name
  description
  registertxt1
  registertxt2
  registertxt3
}

entity tTdmGroupIA {
  foreign_key(groupID)
  foreign_key(iaID)
  datatype
  val_str
  val_double
  val_int
  val_time
}

entity tTdmGroupIANames {
  primary_key(iaID)
  name
  refCount
  datatype
}

entity tTdmChannel {
  primary_key(channelID)
  foreign_key(groupID)
  channelIndex
  name
  datatype
  description
  unit_string
  registertxt1
  ...
}

entity tTdmChannelIA {
  foreign_key(channelID)
  foreign_key(iaID)
  datatype
  val_str
  val_double
  val_int
  val_time
}

entity tTdmChannelIANames {
  primary_key(iaID)
  name
  refCount
  datatype
}

entity tSearchArea {
  primary_key(saID)
  foreign_key(dirID)
  dfpath
  clientpath
  updated
  includeStatus
}

tDirectory ||--o{ tFile : dirID
tFile ||--o{ tTdmFileview : fileID
tTdmFileview ||--o{ tTdmRoot : fileviewID
tTdmRoot ||--o{ tTdmRootIA : rootID
tTdmRootIANames ||--o{ tTdmRootIA : iaID
tTdmRoot ||--o{ tTdmGroup : rootID
tTdmGroup ||--o{ tTdmGroupIA : groupID
tTdmGroupIANames ||--o{ tTdmGroupIA : iaID
tTdmGroup ||--o{ tTdmChannel : groupID
tTdmChannel ||--o{ tTdmChannelIA : channelID
tTdmChannelIANames ||--o{ tTdmChannelIA : iaID
tDirectory ||--o{ tSearchArea : dirID
@enduml
```


```mermaid
erDiagram

    %% Top-level root entity
    tTdmRoot {
        int rootID PK
        int fileviewID FK
        string name
        string description
        string title
        string author
        string datetime
        string registertxt1
        string registertxt2
        string registertxt3
    }

    %% File and indexing
    tTdmFileview {
        int tdmfileviewID PK
        int fileID FK
        int iaID FK
        int indexStatus
        string errorLog
        int modifyTimeAtIndexing
        int indexingTime
        int fileviewSize
    }

    tFile {
        int fileID PK
        int dirID FK
        string name
        int filesize
        int createTime
        int modifyTime
        int attributes
    }

    tDirectory {
        int dirID PK
        int parentDirID
        int rootDirID
        string name
        string fullpath
        int createTime
        int modifyTime
        int included
        int attributes
    }

    tSearchArea {
        int saID PK
        int dirID FK
        string dfpath
        string clientpath
        int updated
        int includeStatus
    }

    tTdmFileviewNames {
        int iaID PK
        string name
        int refCount
        int datatype
    }

    %% Root attributes
    tTdmRootIA {
        int rootID FK
        int iaID FK
        int datatype
        string val_str
        float val_double
        int val_int
        string val_time
    }

    tTdmRootIANames {
        int iaID PK
        string name
        int refCount
        int datatype
    }

    %% Group hierarchy
    tTdmGroup {
        int groupID PK
        int rootID FK
        int groupIndex
        string name
        string description
        string registertxt1
        string registertxt2
        string registertxt3
    }

    tTdmGroupIA {
        int groupID FK
        int iaID FK
        int datatype
        string val_str
        float val_double
        int val_int
        string val_time
    }

    tTdmGroupIANames {
        int iaID PK
        string name
        int refCount
        int datatype
    }

    %% Channel hierarchy
    tTdmChannel {
        int channelID PK
        int groupID FK
        int channelIndex
        string name
        int datatype
        string description
        string unit_string
        string registertxt1
        string registertxt2
        string registertxt3
    }

    tTdmChannelIA {
        int channelID FK
        int iaID FK
        int datatype
        string val_str
        float val_double
        int val_int
        string val_time
    }

    tTdmChannelIANames {
        int iaID PK
        string name
        int refCount
        int datatype
    }

    %% Global metadata
    tMasterInformation {
        string name PK
        string val_str
        float val_double
        int val_int
    }

    %% Relationships (top-down)
    tTdmRoot ||--o{ tTdmFileview : "fileviewID"
    tTdmFileview ||--o{ tFile : "fileID"
    tFile ||--o{ tDirectory : "dirID"
    tDirectory ||--o{ tSearchArea : "dirID"
    tTdmFileview ||--o{ tTdmFileviewNames : "iaID"

    tTdmRoot ||--o{ tTdmRootIA : "rootID"
    tTdmRootIANames ||--o{ tTdmRootIA : "iaID"

    tTdmRoot ||--o{ tTdmGroup : "rootID"
    tTdmGroup ||--o{ tTdmGroupIA : "groupID"
    tTdmGroupIANames ||--o{ tTdmGroupIA : "iaID"

    tTdmGroup ||--o{ tTdmChannel : "groupID"
    tTdmChannel ||--o{ tTdmChannelIA : "channelID"
    tTdmChannelIANames ||--o{ tTdmChannelIA : "iaID"
```


